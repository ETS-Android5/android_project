package com.MyDay.myday1;

public class Data {
    int Date;
    int Emot;

    public Data(int date, int emot) {
        Date = date;
        Emot = emot;
    }

    public int getDate() {
        return Date;
    }

    public int getEmot() {

        return Emot;
    }

    public void setDate(int date) {
        Date = date;
    }

    public void setEmot(int emot) {
        Emot = emot;
    }
}


